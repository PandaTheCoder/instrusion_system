"use strict";(()=>{var e={};e.id=240,e.ids=[240],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55315:e=>{e.exports=require("path")},67825:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>c,patchFetch:()=>m,requestAsyncStorage:()=>R,routeModule:()=>u,serverHooks:()=>g,staticGenerationAsyncStorage:()=>T});var o={};r.r(o),r.d(o,{POST:()=>l});var a=r(49303),s=r(88716),E=r(60670),n=r(87070),i=r(28190);async function l(e){try{let t=await e.json();console.log(t);let r=await i.Y.getViolationsByDateRange(t.startDate,t.endDate);return n.NextResponse.json(r)}catch(e){return n.NextResponse.json({error:e},{status:500})}}let u=new a.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/forms/route",pathname:"/forms",filename:"route",bundlePath:"app/forms/route"},resolvedPagePath:"C:\\Projects\\Backend\\Personal\\free-nextjs-admin-dashboard-main\\src\\app\\forms\\route.ts",nextConfigOutput:"",userland:o}),{requestAsyncStorage:R,staticGenerationAsyncStorage:T,serverHooks:g}=u,c="/forms/route";function m(){return(0,E.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:T})}},28190:(e,t,r)=>{r.d(t,{Y:()=>g});let o=require("better-sqlite3");var a=r.n(o),s=r(55315),E=r.n(s);let n=require("fs");var i=r.n(n);let l=E().join(process.cwd(),"data");i().existsSync(l)||i().mkdirSync(l);let u=E().join(l,"database.sqlite"),R=new(a())(u);R.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
  );
`),R.exec(`
  INSERT OR IGNORE INTO users (email, password)
  SELECT 'admin@arctic-geese.com', 'password@123'
  WHERE NOT EXISTS (
    SELECT 1 FROM users WHERE email = 'admin@arctic-geese.com'
  );
`),R.exec(`
  CREATE TABLE IF NOT EXISTS violations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    image TEXT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    camera TEXT NOT NULL,
    zone TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);let T={getAllUsers:R.prepare(`
    SELECT * FROM users 
  `),getLoginInfo:R.prepare(`
    SELECT * FROM users 
    WHERE email  = ?
    AND password = ?
  `),insertViolation:R.prepare(`
    INSERT INTO violations (image, date, time, camera, zone)
    VALUES (?, ?, ?, ?, ?)
  `),getAllViolations:R.prepare(`
    SELECT * FROM violations 
    ORDER BY date DESC, time DESC
  `),getLast5Violations:R.prepare(`
    SELECT * FROM violations 
    ORDER BY date DESC, time DESC
    LIMIT 5
  `),getViolationsByDate:R.prepare(`
    SELECT * FROM violations 
    WHERE date = ? 
    ORDER BY time DESC
  `),getViolationsCountByDate:R.prepare(`
    SELECT COUNT(*) AS TotalViolations
    FROM violations 
    WHERE date = ? 
    ORDER BY time DESC
  `),getViolationsByCamera:R.prepare(`
    SELECT * FROM violations 
    WHERE camera = ? 
    ORDER BY date DESC, time DESC
  `),getViolationsByDateRange:R.prepare(`
    SELECT * FROM violations 
    WHERE date BETWEEN ? AND ? 
    ORDER BY date ASC, time ASC
  `),getViolationsCountByDateRange:R.prepare(`
    SELECT  COUNT(*) AS TotalViolations
    FROM violations 
    WHERE date BETWEEN ? AND ? 
    ORDER BY date ASC, time ASC
  `),getViolationsGroupedByDate:R.prepare(`
    SELECT COUNT(*) As violations,
    date
    FROM violations 
    WHERE date BETWEEN ? AND ?
    GROUP BY date 
    ORDER BY date ASC, time ASC
  `),getViolationsByZone:R.prepare(`
    SELECT 
      zone, 
      COUNT(*) as count 
    FROM violations 
    GROUP BY zone 
    ORDER BY count DESC
  `),getViolationsByZoneForDate:R.prepare(`
    SELECT 
      zone, 
      COUNT(*) as count 
    FROM violations 
    WHERE date = ?
    GROUP BY zone 
    ORDER BY count DESC
  `),getViolationsByZoneForDateRange:R.prepare(`
    SELECT 
      zone, 
      COUNT(*) as count 
    FROM violations 
    WHERE date BETWEEN ? AND ? 
    GROUP BY zone 
    ORDER BY count DESC
  `),getViolationsByHour:R.prepare(`
    SELECT 
      CASE 
        WHEN time LIKE '%AM' THEN 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '00'
                ELSE substr('0' || substr(time, 1, instr(time, ':') - 1), -2)
            END
        ELSE 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '12'
                ELSE substr('0' || (CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) + 12), -2)
            END
    END as hour,
    COUNT(*) as count
    FROM violations 
    
    GROUP BY hour 
    ORDER BY hour ASC
  `),getViolationsByHourForDate:R.prepare(`
    SELECT 
      CASE 
        WHEN time LIKE '%AM' THEN 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '00'
                ELSE substr('0' || substr(time, 1, instr(time, ':') - 1), -2) || ' AM'
            END
        ELSE 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '12'
                ELSE substr('0' || (CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) + 12), -2) || ' PM'
            END
    END as hour,
    COUNT(*) as count
    FROM violations 
    WHERE date = ?
    GROUP BY hour 
    ORDER BY count DESC
    `),getViolationsByHourForDateRange:R.prepare(`
    SELECT 
      CASE 
        WHEN time LIKE '%AM' THEN 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '00'
                ELSE substr('0' || substr(time, 1, instr(time, ':') - 1), -2) || ' AM'
            END
        ELSE 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '12'
                ELSE substr('0' || (CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) + 12), -2) || ' PM'
            END
    END as hour,
    COUNT(*) as count
    FROM violations 
    WHERE date BETWEEN ? AND ?
    GROUP BY hour 
    ORDER BY count DESC
    `)},g={insert:e=>{try{return T.insertViolation.run(e.image,e.date,e.time,e.camera,e.zone)}catch(e){throw Error(`Insert error: ${e.message}`)}},getAllUsers:()=>{try{return T.getAllUsers.all()}catch(e){throw Error(`Get all error: ${e.message}`)}},getAll:()=>{try{return T.getAllViolations.all()}catch(e){throw Error(`Get all error: ${e.message}`)}},getLast5Violations:()=>{try{return T.getLast5Violations.all()}catch(e){throw Error(`Get all error: ${e.message}`)}},getByDate:e=>{try{return T.getViolationsByDate.all(e)}catch(e){throw Error(`Get by date error: ${e.message}`)}},getByCamera:e=>{try{return T.getViolationsByCamera.all(e)}catch(e){throw Error(`Get by camera error: ${e.message}`)}},getByDateRange:(e,t)=>{try{return T.getViolationsByDateRange.all(e,t)}catch(e){throw Error(`Get by date range error: ${e.message}`)}},getVioationsCountByDateRange:(e,t)=>{try{return T.getViolationsCountByDateRange.all(e,t)}catch(e){throw Error(`Get by date range error: ${e.message}`)}},getVioationsGroupedByDate:(e,t)=>{try{return T.getViolationsGroupedByDate.all(e,t)}catch(e){throw Error(`Get by date range error: ${e.message}`)}},getVioationsCountByDate:e=>{try{return T.getViolationsCountByDate.all(e)}catch(e){throw Error(`Get by date range error: ${e.message}`)}},getCountsByZone:()=>{try{return T.getViolationsByZone.all()}catch(e){throw Error(`Get counts by zone error: ${e.message}`)}},getCountsByZoneForDate:e=>{try{return T.getViolationsByZoneForDate.all(e)}catch(e){throw Error(`Get counts by zone error: ${e.message}`)}},getCountsByZoneForDateRange:(e,t)=>{try{return T.getViolationsByZoneForDateRange.all(e,t)}catch(e){throw Error(`Get counts by zone error: ${e.message}`)}},getCountsByHour:()=>{try{return T.getViolationsByHour.all()}catch(e){throw Error(`Get counts by hour error: ${e.message}`)}},getCountsByHourForDate:e=>{try{return T.getViolationsByHourForDate.all(e)}catch(e){throw Error(`Get counts by hour error: ${e.message}`)}},getCountsByHourForDateRange:(e,t)=>{try{return T.getViolationsByHourForDateRange.all(e,t)}catch(e){throw Error(`Get counts by hour error: ${e.message}`)}},getViolationsByDateRange:(e,t)=>{try{return T.getViolationsByDateRange.all(e,t)}catch(e){throw Error(`Get counts by hour error: ${e.message}`)}},getLoginInfo:(e,t)=>{try{return T.getLoginInfo.all(e,t)}catch(e){throw Error(`Get counts by hour error: ${e.message}`)}}}}};var t=require("../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),o=t.X(0,[948,972],()=>r(67825));module.exports=o})();