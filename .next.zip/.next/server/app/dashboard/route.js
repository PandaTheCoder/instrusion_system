"use strict";(()=>{var t={};t.id=81,t.ids=[81],t.modules={20399:t=>{t.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:t=>{t.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55315:t=>{t.exports=require("path")},55189:(t,e,r)=>{r.r(e),r.d(e,{originalPathname:()=>S,patchFetch:()=>C,requestAsyncStorage:()=>T,routeModule:()=>g,serverHooks:()=>c,staticGenerationAsyncStorage:()=>R});var o={};r.r(o),r.d(o,{GET:()=>l,POST:()=>u});var a=r(49303),s=r(88716),n=r(60670),i=r(87070),E=r(28190);async function l(){try{let t=new Date,[e,r,o]=t.toISOString().split("T")[0].split("-"),a=`${o}/${r}/${e}`,s=`$01/${r}/${o}`,n=await E.Y.getVioationsCountByDate(a),l=await E.Y.getVioationsCountByDateRange(s,a),u=await E.Y.getCountsByHourForDate(a),g=await E.Y.getCountsByHourForDateRange(s,a),T=await E.Y.getCountsByZoneForDate(a),R=await E.Y.getCountsByZoneForDateRange(s,a),c=await E.Y.getLast5Violations(),S=new Date;S.setDate(S.getDate()-7);let[C,y,N]=S.toISOString().split("T")[0].split("-"),m=`${N}/${y}/${C}`,D=await E.Y.getVioationsGroupedByDate(m,a);for(;S<=t;){D.some(t=>t.date==m)||D.push({date:m,violations:0}),S.setDate(S.getDate()+1);let[t,e,r]=S.toISOString().split("T")[0].split("-");m=`${r}/${e}/${t}`}return console.log(c),i.NextResponse.json({isLoading:!0,totalIntrusionsToday:n,peakHoursToday:u,vulnerableZoneToday:T,totalIntrusionsMonthly:l,peakHoursMonthly:g,vulnerableZoneMonthly:R,last5Intrusion:c,chartData:D})}catch(t){return i.NextResponse.json({error:"Failed to fetch today's statistics"},{status:500})}}async function u(t){try{let e=await t.json();console.log(e);let r=await E.Y.insert(e);return i.NextResponse.json(r)}catch(t){return i.NextResponse.json({error:t},{status:500})}}let g=new a.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/dashboard/route",pathname:"/dashboard",filename:"route",bundlePath:"app/dashboard/route"},resolvedPagePath:"C:\\Projects\\Backend\\Personal\\free-nextjs-admin-dashboard-main\\src\\app\\dashboard\\route.ts",nextConfigOutput:"",userland:o}),{requestAsyncStorage:T,staticGenerationAsyncStorage:R,serverHooks:c}=g,S="/dashboard/route";function C(){return(0,n.patchFetch)({serverHooks:c,staticGenerationAsyncStorage:R})}},28190:(t,e,r)=>{r.d(e,{Y:()=>R});let o=require("better-sqlite3");var a=r.n(o),s=r(55315),n=r.n(s);let i=require("fs");var E=r.n(i);let l=n().join(process.cwd(),"data");E().existsSync(l)||E().mkdirSync(l);let u=n().join(l,"database.sqlite"),g=new(a())(u);g.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
  );
`),g.exec(`
  INSERT OR IGNORE INTO users (email, password)
  SELECT 'admin@arctic-geese.com', 'password@123'
  WHERE NOT EXISTS (
    SELECT 1 FROM users WHERE email = 'admin@arctic-geese.com'
  );
`),g.exec(`
  CREATE TABLE IF NOT EXISTS violations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    image TEXT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    camera TEXT NOT NULL,
    zone TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);let T={getAllUsers:g.prepare(`
    SELECT * FROM users 
  `),getLoginInfo:g.prepare(`
    SELECT * FROM users 
    WHERE email  = ?
    AND password = ?
  `),insertViolation:g.prepare(`
    INSERT INTO violations (image, date, time, camera, zone)
    VALUES (?, ?, ?, ?, ?)
  `),getAllViolations:g.prepare(`
    SELECT * FROM violations 
    ORDER BY date DESC, time DESC
  `),getLast5Violations:g.prepare(`
    SELECT * FROM violations 
    ORDER BY date DESC, time DESC
    LIMIT 5
  `),getViolationsByDate:g.prepare(`
    SELECT * FROM violations 
    WHERE date = ? 
    ORDER BY time DESC
  `),getViolationsCountByDate:g.prepare(`
    SELECT COUNT(*) AS TotalViolations
    FROM violations 
    WHERE date = ? 
    ORDER BY time DESC
  `),getViolationsByCamera:g.prepare(`
    SELECT * FROM violations 
    WHERE camera = ? 
    ORDER BY date DESC, time DESC
  `),getViolationsByDateRange:g.prepare(`
    SELECT * FROM violations 
    WHERE date BETWEEN ? AND ? 
    ORDER BY date ASC, time ASC
  `),getViolationsCountByDateRange:g.prepare(`
    SELECT  COUNT(*) AS TotalViolations
    FROM violations 
    WHERE date BETWEEN ? AND ? 
    ORDER BY date ASC, time ASC
  `),getViolationsGroupedByDate:g.prepare(`
    SELECT COUNT(*) As violations,
    date
    FROM violations 
    WHERE date BETWEEN ? AND ?
    GROUP BY date 
    ORDER BY date ASC, time ASC
  `),getViolationsByZone:g.prepare(`
    SELECT 
      zone, 
      COUNT(*) as count 
    FROM violations 
    GROUP BY zone 
    ORDER BY count DESC
  `),getViolationsByZoneForDate:g.prepare(`
    SELECT 
      zone, 
      COUNT(*) as count 
    FROM violations 
    WHERE date = ?
    GROUP BY zone 
    ORDER BY count DESC
  `),getViolationsByZoneForDateRange:g.prepare(`
    SELECT 
      zone, 
      COUNT(*) as count 
    FROM violations 
    WHERE date BETWEEN ? AND ? 
    GROUP BY zone 
    ORDER BY count DESC
  `),getViolationsByHour:g.prepare(`
    SELECT 
      CASE 
        WHEN time LIKE '%AM' THEN 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '00'
                ELSE substr('0' || substr(time, 1, instr(time, ':') - 1), -2)
            END
        ELSE 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '12'
                ELSE substr('0' || (CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) + 12), -2)
            END
    END as hour,
    COUNT(*) as count
    FROM violations 
    
    GROUP BY hour 
    ORDER BY hour ASC
  `),getViolationsByHourForDate:g.prepare(`
    SELECT 
      CASE 
        WHEN time LIKE '%AM' THEN 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '00'
                ELSE substr('0' || substr(time, 1, instr(time, ':') - 1), -2) || ' AM'
            END
        ELSE 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '12'
                ELSE substr('0' || (CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) + 12), -2) || ' PM'
            END
    END as hour,
    COUNT(*) as count
    FROM violations 
    WHERE date = ?
    GROUP BY hour 
    ORDER BY count DESC
    `),getViolationsByHourForDateRange:g.prepare(`
    SELECT 
      CASE 
        WHEN time LIKE '%AM' THEN 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '00'
                ELSE substr('0' || substr(time, 1, instr(time, ':') - 1), -2) || ' AM'
            END
        ELSE 
            CASE 
                WHEN CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) = 12 THEN '12'
                ELSE substr('0' || (CAST(substr(time, 1, instr(time, ':') - 1) AS INTEGER) + 12), -2) || ' PM'
            END
    END as hour,
    COUNT(*) as count
    FROM violations 
    WHERE date BETWEEN ? AND ?
    GROUP BY hour 
    ORDER BY count DESC
    `)},R={insert:t=>{try{return T.insertViolation.run(t.image,t.date,t.time,t.camera,t.zone)}catch(t){throw Error(`Insert error: ${t.message}`)}},getAllUsers:()=>{try{return T.getAllUsers.all()}catch(t){throw Error(`Get all error: ${t.message}`)}},getAll:()=>{try{return T.getAllViolations.all()}catch(t){throw Error(`Get all error: ${t.message}`)}},getLast5Violations:()=>{try{return T.getLast5Violations.all()}catch(t){throw Error(`Get all error: ${t.message}`)}},getByDate:t=>{try{return T.getViolationsByDate.all(t)}catch(t){throw Error(`Get by date error: ${t.message}`)}},getByCamera:t=>{try{return T.getViolationsByCamera.all(t)}catch(t){throw Error(`Get by camera error: ${t.message}`)}},getByDateRange:(t,e)=>{try{return T.getViolationsByDateRange.all(t,e)}catch(t){throw Error(`Get by date range error: ${t.message}`)}},getVioationsCountByDateRange:(t,e)=>{try{return T.getViolationsCountByDateRange.all(t,e)}catch(t){throw Error(`Get by date range error: ${t.message}`)}},getVioationsGroupedByDate:(t,e)=>{try{return T.getViolationsGroupedByDate.all(t,e)}catch(t){throw Error(`Get by date range error: ${t.message}`)}},getVioationsCountByDate:t=>{try{return T.getViolationsCountByDate.all(t)}catch(t){throw Error(`Get by date range error: ${t.message}`)}},getCountsByZone:()=>{try{return T.getViolationsByZone.all()}catch(t){throw Error(`Get counts by zone error: ${t.message}`)}},getCountsByZoneForDate:t=>{try{return T.getViolationsByZoneForDate.all(t)}catch(t){throw Error(`Get counts by zone error: ${t.message}`)}},getCountsByZoneForDateRange:(t,e)=>{try{return T.getViolationsByZoneForDateRange.all(t,e)}catch(t){throw Error(`Get counts by zone error: ${t.message}`)}},getCountsByHour:()=>{try{return T.getViolationsByHour.all()}catch(t){throw Error(`Get counts by hour error: ${t.message}`)}},getCountsByHourForDate:t=>{try{return T.getViolationsByHourForDate.all(t)}catch(t){throw Error(`Get counts by hour error: ${t.message}`)}},getCountsByHourForDateRange:(t,e)=>{try{return T.getViolationsByHourForDateRange.all(t,e)}catch(t){throw Error(`Get counts by hour error: ${t.message}`)}},getViolationsByDateRange:(t,e)=>{try{return T.getViolationsByDateRange.all(t,e)}catch(t){throw Error(`Get counts by hour error: ${t.message}`)}},getLoginInfo:(t,e)=>{try{return T.getLoginInfo.all(t,e)}catch(t){throw Error(`Get counts by hour error: ${t.message}`)}}}}};var e=require("../../webpack-runtime.js");e.C(t);var r=t=>e(e.s=t),o=e.X(0,[948,972],()=>r(55189));module.exports=o})();